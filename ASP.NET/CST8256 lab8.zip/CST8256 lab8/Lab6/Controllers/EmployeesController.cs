﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Lab6.Models.DataAccess;
using Lab6.Models.ViewModel;

namespace Lab6.Controllers
{
    public class EmployeesController : Controller
    {
        private readonly StudentRecordContext _context;

        public EmployeesController(StudentRecordContext context)
        {
            _context = context;
        }

        // GET: Employees
        public async Task<IActionResult> Index()
        {
            return _context.Employees != null ?
                        View(await _context.Employees.Include(a => a.Roles).ToListAsync()) :
                        Problem("Entity set 'StudentRecordContext.Employees'  is null.");
        }
         
        public async Task<IActionResult> Create()
        {
            //return View();

            var employee = new Employee();
            List<Role> roles = await _context.Roles.ToListAsync();

            var employeeRoleSelections = new EmployeeRoleSelections(employee, roles);

            return View(employeeRoleSelections);
        }

        // POST: Employees/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(EmployeeRoleSelections employeeRoleSelections)
        {
                foreach (RoleSelection roleSelection in employeeRoleSelections.roleSelections)
                {
                    if (roleSelection.Selected)
                    {
                        Role role = _context.Roles.SingleOrDefault(r => r.Id == roleSelection.role.Id);
                        employeeRoleSelections.employee.Roles.Add(role);
                    }
                }

                _context.Add(employeeRoleSelections.employee);
                await _context.SaveChangesAsync();
                return RedirectToAction("Index");
        }

        // GET: Employees/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Employees == null)
            {
                return NotFound();
            }

            var employee = _context.Employees
                .Include(e => e.Roles)
                .SingleOrDefault(e => e.Id == id);


            if (employee == null)
            {
                return NotFound();
            }

            var roles = await _context.Roles.ToListAsync();
            EmployeeRoleSelections employeeRoleSelections = new EmployeeRoleSelections(employee, roles);
            employeeRoleSelections.employee = employee;

            foreach (RoleSelection selection in employeeRoleSelections.roleSelections)
            {
                foreach (Role role in employee.Roles)
                {
                    if (role.Id == selection.role.Id)
                    {
                        selection.Selected = true;
                    }
                }
            }
            return View(employeeRoleSelections);
        }

        // POST: Employees/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(EmployeeRoleSelections employeeRoleSelections)
        {
            if(!employeeRoleSelections.roleSelections.Any(m => m.Selected))
            {
                ModelState.AddModelError("roleSelections", "one must be selected");
            }

            if(_context.Employees.Any(e=>e.UserName == employeeRoleSelections.employee.UserName && e.Id != employeeRoleSelections.employee.Id))
            {
                ModelState.AddModelError("employee.UserName", "user name already taken");
            }

            if (ModelState.IsValid)
            {
                Employee theEmployee = employeeRoleSelections.employee;
                Employee employee = await _context.Employees.Include(e => e.Roles)
                    .SingleOrDefaultAsync(e => e.Id == employeeRoleSelections.employee.Id);
                employee.Roles.Clear();
                foreach (RoleSelection roleSelection in employeeRoleSelections.roleSelections)
                {
                    if (roleSelection.Selected)
                    {
                        Role role = _context.Roles.SingleOrDefault(r => r.Id == roleSelection.role.Id);
                        employee.Roles.Add(role);
                    }
                }
                employee.Name = theEmployee.Name;
                employee.UserName = theEmployee.UserName;
                employee.Password = theEmployee.Password;

                _context.Update(employee);
                _context.SaveChanges();

                return RedirectToAction(nameof(Index));
            }
            //employeeRoleSelections.CreateRoleSelections(_context.Roles.ToList());

            var emp = _context.Employees
                .Include(e => e.Roles)
                .SingleOrDefault(e => e.Id == employeeRoleSelections.employee.Id);

            var roles = await _context.Roles.ToListAsync();
            EmployeeRoleSelections empRoleSelections = new EmployeeRoleSelections(emp, roles);
            employeeRoleSelections.employee = emp;

            foreach (RoleSelection selection in employeeRoleSelections.roleSelections)
            {
                foreach (Role role in emp.Roles)
                {
                    if (role.Id == selection.role.Id)
                    {
                        selection.Selected = true;
                    }
                }
            }

            return View(empRoleSelections);
        }
        private bool EmployeeExists(int id)
        {
            return (_context.Employees?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}

/*
namespace Lab6.Controllers
{
    public class EmployeesController : Controller
    {
        private readonly StudentRecordContext _context;

        public EmployeesController(StudentRecordContext context)
        {
            _context = context;
        }

        // GET: Employees
        public async Task<IActionResult> Index()
        {
              return _context.Employees != null ? 
                          View(await _context.Employees.ToListAsync()) :
                          Problem("Entity set 'StudentRecordContext.Employees'  is null.");
        }

        // GET: Employees/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Employees == null)
            {
                return NotFound();
            }

            var employee = await _context.Employees
                .FirstOrDefaultAsync(m => m.Id == id);
            if (employee == null)
            {
                return NotFound();
            }

            return View(employee);
        }

        // GET: Employees/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Employees/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Name,UserName,Password")] Employee employee)
        {
            if (ModelState.IsValid)
            {
                _context.Add(employee);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(employee);
        }

        // GET: Employees/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Employees == null)
            {
                return NotFound();
            }

            var employee = await _context.Employees.FindAsync(id);
            if (employee == null)
            {
                return NotFound();
            }
            return View(employee);
        }

        // POST: Employees/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Name,UserName,Password")] Employee employee)
        {
            if (id != employee.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(employee);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!EmployeeExists(employee.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(employee);
        }

        // GET: Employees/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Employees == null)
            {
                return NotFound();
            }

            var employee = await _context.Employees
                .FirstOrDefaultAsync(m => m.Id == id);
            if (employee == null)
            {
                return NotFound();
            }

            return View(employee);
        }

        // POST: Employees/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Employees == null)
            {
                return Problem("Entity set 'StudentRecordContext.Employees'  is null.");
            }
            var employee = await _context.Employees.FindAsync(id);
            if (employee != null)
            {
                _context.Employees.Remove(employee);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool EmployeeExists(int id)
        {
          return (_context.Employees?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
        */