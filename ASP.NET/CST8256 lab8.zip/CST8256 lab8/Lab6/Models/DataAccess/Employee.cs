﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;
using Lab6.Models.DataAccess;
using Lab6.Models.ViewModel;

namespace Lab6.Models.DataAccess
{
    public partial class Employee
    {
        public Employee()
        {
            Roles = new HashSet<Role>();
        }

        public int Id { get; set; }

        [Required(ErrorMessage = "Name is required")]
        [RegularExpression(@"^[a-zA-Z]+([ '-][a-zA-Z]+)* [a-zA-Z]+([ '-][a-zA-Z]+)*$", ErrorMessage = "Enter a valid first and last name")]
        public string Name { get; set; } = null!;

        [Required(ErrorMessage = "User name is required")]
        [StringLength(50, MinimumLength = 3, ErrorMessage = "User Name must be at least 3 characters")]
        public string UserName { get; set; } = null!;

        [Required(ErrorMessage = "Password is required")]
        [StringLength(50, MinimumLength = 5, ErrorMessage = "Password must be at least 5 characters")]
        public string Password { get; set; } = null!;
        public virtual ICollection<Role> Roles { get; set; }

        public string DisplayRoles
        {
            get
            {
                string allRoles = "";
                List<Role> roles = Roles.ToList();
                for (int i = 0; i < roles.Count(); i++)
                {
                    allRoles += roles[i].Role1;
                    if (i < roles.Count - 1)
                    {
                        allRoles += ", ";
                    }
                }
                return allRoles;
            }
        }
    }
}