﻿using System;
using System.Collections.Generic;

namespace Lab6.Models.DataAccess
{
    public partial class Employee
    {
        public Employee()
        {
            Roles = new HashSet<Role>();
        }

        public int Id { get; set; }
        public string Name { get; set; } = null!;
        public string UserName { get; set; } = null!;
        public string Password { get; set; } = null!;

        public virtual ICollection<Role> Roles { get; set; }

        public string DisplayRoles
        {
            get
            {
                string allRoles = "";
                List<Role> roles = Roles.ToList();
                for (int i = 0; i < roles.Count(); i++)
                {
                    allRoles += roles[i].Role1;
                    if (i < roles.Count - 1)
                    {
                        allRoles += ", ";
                    }
                }
                return allRoles;
            }
        }
    }
}
